<?php

include get_stylesheet_directory() . '/inc/class-file-manager.php';
include get_stylesheet_directory() . '/inc/enqueue-scripts.php';
include get_stylesheet_directory() . '/inc/submission-post-type.php';
// include get_stylesheet_directory() . '/inc/theme-options.php';
include get_stylesheet_directory() . '/inc/handle-csv-upload.php';
include get_stylesheet_directory() . '/inc/serve-json-data.php';
