<?php
/**
 * The main template file
 */

get_header();?>

<div id="map"></div>

<?php get_footer();
