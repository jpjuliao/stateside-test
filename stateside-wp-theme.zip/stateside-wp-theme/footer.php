<?php
/**
 * The template for displaying the footer
 */

?>
			</main><!-- #main -->
		</div><!-- #primary -->
	</div><!-- #content -->


</div><!-- #page -->

<script
  src="https://maps.googleapis.com/maps/api/js?key=<?php echo API_KEY ?>&callback=initMap&v=weekly"
  defer
></script>

<?php wp_footer(); ?>

</body>
</html>
